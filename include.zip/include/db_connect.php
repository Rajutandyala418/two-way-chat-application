<?php
$servername = "localhost";
$username   = "root";
$password   = "";  // as provided
$dbname     = "mini_chat_app";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
